You can run this program using the following command -

python scanner.py <pcap-file>

It is written in python 2.7.15 and has been tested on the CS machine rockhopper-02.